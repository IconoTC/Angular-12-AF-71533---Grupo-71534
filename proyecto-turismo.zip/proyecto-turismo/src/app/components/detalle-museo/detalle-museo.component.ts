import { MuseosService } from 'src/app/services/museos.service';
import { Component, OnInit } from '@angular/core';
import { Museo } from 'src/app/models/museo';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detalle-museo',
  templateUrl: './detalle-museo.component.html',
  styleUrls: ['./detalle-museo.component.css']
})
export class DetalleMuseoComponent implements OnInit {

  id: number = 0;
  museo?: Museo;

  constructor(private museosService: MuseosService, private ruta: ActivatedRoute) { 
    this.id = ruta.snapshot.params['codigo'];
    this.museo = museosService.buscarMuseo(this.id);
  }

  ngOnInit(): void {
  }

}
