import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  texto: string = "Bienvenidos al curso de Angular";

  numero: number = 868754333.45567888;
  porcentaje:number = 0.5359887;

  // Funciona de diferentes formas
  fecha: Date = new Date();
  fecha2: Date = new Date('12/31/2024');   // mes/dia/año
  fecha3: string = '12/31/2024';

  persona: Object = {
    nombre: 'Pepito',
    apellido: 'Perez',
    telefonos: {
      tel1: 911234567,
      tel2: 616123456
    }
  }
}
