import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  alumnos: any[] = [
    {nombre: 'Juan', apellido: 'Lopez', nota: 7.5},
    {nombre: 'Maria', apellido: 'Sanchez', nota: 5.8},
    {nombre: 'Elena', apellido: 'Arias', nota: 3.2},
    {nombre: 'Roberto', apellido: 'Rodriguez', nota: 6.4},
    {nombre: 'Javier', apellido: 'Martin', nota: 4.1},
    {nombre: 'Marta', apellido: 'Gonzalez', nota: 8.3}
  ];
}
